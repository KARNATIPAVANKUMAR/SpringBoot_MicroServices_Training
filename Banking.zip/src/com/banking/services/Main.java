package com.banking.services;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<User> user = new ArrayList<User>();
		User u1 = new User(1, "Ram", 1000, "SA");
		user.add(u1);
		User u2 = new User(2, "Rahim", 2000, "SA");
		user.add(u2);
		User u3 = new User(3, "Jam", 3000, "SA");
		user.add(u3);
		User u4 = new User(4, "Ravi", 4000, "SA");
		user.add(u4);
		User u5 = new User(5, "Bhuvi", 5000, "SA");
		user.add(u5);
		User u6 = new User(1, "Apple", 500000, "CA");
		user.add(u6);
		User u7 = new User(2, "Apple", 400000, "CA");
		user.add(u7);
		User u8 = new User(3, "Banana", 300000, "CA");
		user.add(u8);
		User u9 = new User(4, "Mango", 200000, "CA");
		user.add(u9);
		User u10 = new User(5, "Guava", 100000, "CA");
		user.add(u10);

		SavingsAccount sa = new SavingsAccount();
		CurrentAccount ca = new CurrentAccount();
		sa.credit(500, u1);
		sa.debit(200, u1);
		System.out.println("Hello " + u1.getName() + " Your " + u1.getAccounttype() + " Balance is " + u1.getAmount());

		ca.credit(500, u6);
		ca.debit(200, u6);
		System.out.println("Hello " + u6.getName() + " Your " + u6.getAccounttype() + " Balance is " + u6.getAmount());

	}

}
